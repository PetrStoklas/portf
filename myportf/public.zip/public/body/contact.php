<?php include_once 'mail/mail.php';  //mail includes the db itself ?> <form id="contact" class="contact" method="post" action="#contact"><!-- PROVIZORNI KONTAKTY--><!-- <div class="contacts" id=#contacts>
        <h2 class="cntct-header">contacts</h2>               

        <a class="cntct-link" href="mailto:petrstoklas@gmail.com?">petrstoklas@gmail.com</a>

        <a class="cntct-link" href="http://www.linkedin.com/in/petrstoklas">my linkedin</a>
    </div> --><div class="left"><input class="name" type="text" name="fname" placeholder="   First Name"> <input class="name" type="text" name="sname" placeholder="  Second Name"> <input class="name" type="mail" name="mail" placeholder="  Your Email"></div><div class="mid"><textarea class="lng-txt" name="long_text" placeholder="  Type your message here..."></textarea> <button class="submit-btn" type="submit" name="submit">Send Me Message!</button></div><img src="img/shark-final.svg" alt="#" class="logo-bottom"></form> <?php// foreach ($messages as $message) : ?> <div class="message"> <?//php echo $message; ?> </div> <?php// endforeach; ?>